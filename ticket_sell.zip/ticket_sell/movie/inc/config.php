<?php
session_start(); /* Session */
$con=mysqli_connect("localhost","dizitech_tickpic","my]jgme;SjX?","dizitech_tickpick"); /*Database Connection*/
?>

$('.sub-menu').click(function() {
  console.log('clciked');
   $('.header').toggleClass('_fixed-menu');
});